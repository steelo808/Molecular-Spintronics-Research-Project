var searchData=
[
  ['deserializationexception_0',['DeserializationException',['../d5/df1/classudc_1_1_molecule_1_1_deserialization_exception.html',1,'udc::Molecule']]]
];
